const agregarLimon = document.getElementById('agregarLimon')
const agregarTomate = document.getElementById('agregarTomate')
const agregarAguacate = document.getElementById('agregarAguacate')
const agregarNopal = document.getElementById('agregarNopal')
const agregarTomateVerde = document.getElementById('agregarTomateVerde')
const agregarCocaSinAzucar = document.getElementById('agregarCocaSinAzucar')
const agregarCoca = document.getElementById('agregarCoca')
const agregarPavo = document.getElementById('agregarPavo')
const agregarPan = document.getElementById('agregarPan')
const agregarMayonesa = document.getElementById('agregarMayonesa')
const agregarColgate = document.getElementById('agregarColgate')
const agregarHuevos = document.getElementById('agregarHuevos')
const agregarFabuloso = document.getElementById('agregarFabuloso')

agregarLimon.addEventListener('click', ()=>{
    
})