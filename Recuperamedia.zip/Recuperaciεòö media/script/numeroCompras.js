const items = document.getElementById('itemsNumeroCompras')
const templateCard = document.getElementById('numeroCompras').content;
const fragment = document.createDocumentFragment();

var numeroCompras= localStorage.getItem('numeroCompras')

let predeterminado = 0

if (numeroCompras  >= 1){
}else{
    localStorage.setItem('numeroCompras', 0)
}

document.addEventListener('DOMContentLoaded',()=>{
    LoadData()
})

const LoadData = () => {
    let numero = localStorage.getItem('numeroCompras')
    templateCard.querySelector('p').textContent = numero
    const clone = templateCard.cloneNode(true)
    fragment.appendChild(clone)
    items.appendChild(fragment)
}
