window.addEventListener('load', ()=>{
    new Glider(document.querySelector('#lineaProductos1'), 
    {
        slidesToShow: 5,
        slidesToScroll: 1,
        draggable: true,
    });
})
window.addEventListener('load', ()=>{
    new Glider(document.querySelector('#lineaProductos2'), 
    {
        slidesToShow: 5,
        slidesToScroll: 1,
        draggable: true,
    });
})